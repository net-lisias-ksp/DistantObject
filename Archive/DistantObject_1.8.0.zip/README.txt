Distant Object Enhancement bis
=============

This plugin renders effects for distant objects in Kerbal Space Program v1.1 and later.

Original plugin by duckytopia (Rubber Ducky on the KSP forum).

Distant Object Enhancement bis update by MOARdV.

This release's forum thread:
http://forum.kerbalspaceprogram.com/index.php?/topic/89214-105-distant-object-enhancement-bis-v164-21-november-2015/

Original Forum thread:
http://forum.kerbalspaceprogram.com/index.php?/topic/63457-024-distant-object-enhancement-131-planetssatellites-in-the-night-sky-729/

Source Code:
https://github.com/MOARdV/DistantObject

Documentation:
https://github.com/MOARdV/DistantObject/wiki

License:

Creative Commons Attribution 4.0 International

http://creativecommons.org/licenses/by/4.0/
